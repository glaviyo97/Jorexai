import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = 3000;

app.use(express.json());

const requireAuth = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
  // Authentication disabled
  next();
};

let aiClient: GoogleGenAI | null = null;
function getAI() {
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY || "missing-key",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// 1. Intent Detection
app.post("/api/intent", requireAuth, async (req, res) => {
  try {
    const ai = getAI();
    const { message } = req.body;
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Classify the following user message into exactly ONE of these intents: "IMAGE", "VIDEO", "FILE", "CODE", or "TEXT". 
      Only return the exact single word, nothing else. 
      "IMAGE" if they explicitly ask to generate/create/draw an image/picture/photo. 
      "VIDEO" if they explicitly ask to generate/make/animate a video. 
      "FILE" if they explicitly ask to create/generate a downloadable file or document. 
      "CODE" if they ask for code generation, code debugging, programming explanation, or software development.
      "TEXT" for chat, questions, writing, or anything else.
      Message: "${message}"`,
      config: {
        systemInstruction: "You are an intent router. Return exactly one word.",
        temperature: 0,
      },
    });
    
    const intent = response.text?.trim().toUpperCase() || "TEXT";
    res.json({ intent });
  } catch (err: any) {
    console.error("Intent error:", err);
    res.status(500).json({ error: err.message });
  }
});

// 2. Chat / Text / Code completion
app.post("/api/chat", requireAuth, async (req, res) => {
  try {
    const ai = getAI();
    const { messages, intent } = req.body; // array of {role, content}
    const prompt = messages[messages.length - 1].content;
    
    const isCode = intent === "CODE";
    const selectedModel = isCode ? "gemini-2.5-pro" : "gemini-2.5-flash";
    
    const responseStream = await ai.models.generateContentStream({
      model: selectedModel,
      contents: prompt,
      config: {
        systemInstruction: "You are Jerox AI, a premium AI assistant for a modern futuristic SaaS platform. Provide professional, concise, and accurate responses.",
      }
    });

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    for await (const chunk of responseStream) {
      if (chunk.text) {
        res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
      }
    }
    res.write("data: [DONE]\n\n");
    res.end();
  } catch (err: any) {
    console.error("Chat error:", err);
    res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
    res.end();
  }
});

// 3. Image Generation
app.post("/api/image", requireAuth, async (req, res) => {
  try {
    const ai = getAI();
    const { prompt } = req.body;
    const response = await ai.models.generateImages({
      model: "imagen-4.0-generate-001",
      prompt: prompt,
      config: {
        numberOfImages: 1,
        outputMimeType: "image/jpeg",
        aspectRatio: "1:1",
      }
    });

    const base64EncodeString = response.generatedImages[0].image.imageBytes;
    if (!base64EncodeString) throw new Error("No image generated");
    
    const imageUrl = `data:image/jpeg;base64,${base64EncodeString}`;
    res.json({ imageUrl });
  } catch (err: any) {
    console.error("Image error:", err);
    res.status(500).json({ error: err.message });
  }
});

// 4. Video Generation (Veo API)
app.post("/api/video", requireAuth, async (req, res) => {
  try {
    const ai = getAI();
    let { prompt } = req.body;
    
    // Enforce performance prompt rules
    prompt = prompt + " (Limit duration strictly to maximum 8 seconds. Use standard quality formatting.)";

    const operation = await ai.models.generateVideos({
      model: 'veo-3.1-lite-generate-preview',
      prompt: prompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9',
        durationSeconds: 8
      }
    });
    
    // Return early, client must handle polling.
    res.json({ operationName: operation.name });
  } catch (err: any) {
    console.error("Video error:", err);
    res.status(500).json({ error: err.message });
  }
});

import { GenerateVideosOperation } from '@google/genai';

app.post("/api/video-status", requireAuth, async (req, res) => {
  try {
    const ai = getAI();
    const { operationName } = req.body;
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });
    res.json({ done: updated.done, response: updated.response });
  } catch (err: any) {
    console.error("Video poll error:", err);
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/video-download", requireAuth, async (req, res) => {
  try {
    const ai = getAI();
    const operationName = req.query.op as string;
    if (!operationName) throw new Error("Missing operationName");
    
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });
    const uri = updated.response?.generatedVideos?.[0]?.video?.uri;
    
    if (!uri) {
      return res.status(404).json({ error: "Video URI not found" });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    const videoRes = await fetch(uri, {
      headers: { 'x-goog-api-key': apiKey || '' },
    });
    
    res.setHeader('Content-Type', 'video/mp4');
    
    if (videoRes.body) {
      videoRes.body.pipeTo(
        new WritableStream({
          write(chunk: Uint8Array) { res.write(chunk); },
          close() { res.end(); },
        })
      );
    } else {
      res.status(500).json({ error: "Failed to download video stream" });
    }
  } catch (err: any) {
    console.error("Video download error:", err);
    res.status(500).json({ error: err.message });
  }
});



// 5. Fake Razorpay Integration Endpoint
app.post("/api/payment/create-order", requireAuth, async (req, res) => {
  try {
    const key = process.env.RAZORPAY_KEY_ID;
    const secret = process.env.RAZORPAY_KEY_SECRET;
    
    if (!key || !secret) {
      return res.status(500).json({ error: "Payment system is not configured yet." });
    }

    const { amount, plan } = req.body;
    // mock order ID
    const orderId = `order_${Math.random().toString(36).substring(2, 10)}`;
    res.json({ id: orderId, amount: amount * 100, currency: "INR", plan });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

import { createClient } from "@supabase/supabase-js";
function getSupabase() {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.VITE_SUPABASE_ANON_KEY;
  if (url && key) {
    return createClient(url, key);
  }
  return null;
}

app.post("/api/payment/verify-order", requireAuth, async (req, res) => {
  try {
    const key = process.env.RAZORPAY_KEY_ID;
    const secret = process.env.RAZORPAY_KEY_SECRET;
    
    if (!key || !secret) {
      return res.status(500).json({ error: "Payment system is not configured yet." });
    }
    const { orderId, plan, userId } = req.body;
    // mock verification
    const isSignatureValid = true;

    if (isSignatureValid) {
       // Store subscription securely in Supabase
        const supabase = getSupabase();
       if (supabase && userId) {
          // Verify payment on the backend before updating the user's subscription.
          const expiryDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
          const { data: existing } = await supabase.from("user_subscriptions").select("id").eq("user_id", userId).single();
          if (existing) {
             await supabase.from("user_subscriptions").update({
               plan: plan.toLowerCase(),
               expiry_date: expiryDate,
               updated_at: new Date().toISOString()
             }).eq("user_id", userId);
          } else {
             await supabase.from("user_subscriptions").insert({
               user_id: userId,
               plan: plan.toLowerCase(),
               chat_count: 0,
               coding_count: 0,
               image_count: 0,
               video_count: 0,
               monthly_reset_date: new Date().toISOString(),
               daily_reset_date: new Date().toISOString(),
               expiry_date: expiryDate,
               updated_at: new Date().toISOString()
             });
          }
       }
       res.json({ success: true, plan: plan.toLowerCase(), expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() });
    } else {
       res.status(400).json({ error: "Invalid payment signature" });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
